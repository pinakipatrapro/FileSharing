module.exports = {
    user: 'postgres',
    database: 'pgdocker',
    password: '123',
    host: 'localhost',
    port: 5432,
    max: 10,
    idleTimeoutMillis: 30000
};