const { Pool } = require('pg');
var config = require("./config/db.config.js");
const pool = new Pool(config);

pool.on('error', function (err, client) {
    console.error('idle client error', err.message, err.stack);
});

pool.query('SELECT * FROM public.db_users',  function(err, res) {
    if(err) {
        return console.error('error running query', err);
    }
    console.log('number:', res.rows[0]);
});

